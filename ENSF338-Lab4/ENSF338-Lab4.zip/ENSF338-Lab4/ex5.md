Question 1

The various things that these functions must account for are the following:
- CPU: How fast the CPU can handle the tasks at hand
- Garbage Collection: How data that is not being used anymore is being handled
- Disk I/O (overall resource usage): Resource allocation on the computer and how much breathing room it's able to have when computing or accessing/reading files.
- JIT Compliation: Just-in-Time code where first execution of a function may be slower than the subsequent calls

When timeit.timeit is most appropiate:
- When you just need the basic functionality of timing a specific function x amount of times
- Can reduce variance via the number= paramater to average out random fluctuations

When timeit.repeat is most appropiate:
- Allows you to repeat the entire execution multiple times which could further pinpoint fluctuations
- timeit.repeat is also good to mitigate JIT compilation times in being able to execute more times
- Overall for more rigorous/extensive benchmarking of times

Question 2

